<?php
 $connection = mysqli_connect('localhost','root','','db_blog_app')
?>

/*
CREATE TABLE blogUser (
    userId INT AUTO_INCREMENT PRIMARY KEY,
    userName VARCHAR(255) NOT NULL,
    userEmail VARCHAR(255) NOT NULL,
    userPassword VARCHAR(255) NOT NULL
);

CREATE TABLE Blog (
    blogId INT AUTO_INCREMENT PRIMARY KEY,
    blogName VARCHAR(255) NOT NULL,
    blogDescription TEXT
);


 */
