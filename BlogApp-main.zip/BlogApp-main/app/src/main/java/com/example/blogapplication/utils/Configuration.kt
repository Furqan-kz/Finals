package com.example.blogapplication.utils

object Configuration {
    const val Base_Url = "https://192.168.0.104/BlogApp/"
}